package com.compiler;

/**
 * @author y
 */
public class ClickHelper {

    public int id;
    public boolean hasClick;
    public String clickMethodName;
    public boolean hasLongClick;
    public String longClickMethodName;
}
