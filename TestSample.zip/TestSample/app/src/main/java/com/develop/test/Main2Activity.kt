package com.develop.test

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * @author y
 * @create 2019/3/8
 */
class Main2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}