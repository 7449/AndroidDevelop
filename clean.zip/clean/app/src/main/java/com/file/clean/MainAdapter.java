package com.file.clean;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.file.clean.util.FileUtils;

import java.util.ArrayList;

public class MainAdapter extends BaseAdapter {

    private ArrayList<ListBean> listBeans = new ArrayList<>();

    @Override
    public int getCount() {
        return listBeans.size();
    }

    @Override
    public ListBean getItem(int i) {
        return listBeans.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    public void addAll(ArrayList<ListBean> arrayList) {
        listBeans.addAll(arrayList);
        notifyDataSetChanged();
    }

    public void removeAll() {
        listBeans.clear();
        notifyDataSetChanged();
    }

    public ArrayList<ListBean> getAllBeans() {
        return listBeans;
    }

    public void removeAllFile() {
        for (ListBean listBean : listBeans) {
            FileUtils.deleteFile(listBean.getFile());
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_main, null);
            viewHolder.fileName = (TextView) convertView.findViewById(R.id.tv_file_name);
            viewHolder.filePath = (TextView) convertView.findViewById(R.id.tv_file_path);
            viewHolder.fileDelete = (TextView) convertView.findViewById(R.id.tv_file_delete);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        ListBean bean = listBeans.get(position);
        viewHolder.fileName.setText(bean.getFile().getName() + (bean.getFile().isDirectory() ? "(文件夹)" : "(文件)"));
        viewHolder.filePath.setText(bean.getFile().getPath());
        viewHolder.fileDelete.setText(bean.getFile().exists() ? "未删除" : "已删除");
        return convertView;
    }

    private static class ViewHolder {
        private TextView fileName;
        private TextView fileDelete;
        private TextView filePath;
    }
}
