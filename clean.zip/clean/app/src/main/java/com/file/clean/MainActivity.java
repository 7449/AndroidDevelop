package com.file.clean;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.widget.ListView;
import android.widget.Toast;

import com.file.clean.util.DialogUtils;
import com.file.clean.util.FileUtils;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends Activity {

    private File rootFile = Environment.getExternalStorageDirectory();
    private MainAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (!rootFile.exists()) {
            toast("没有获取到根目录");
            finish();
            return;
        }
        mAdapter = new MainAdapter();
        ListView mListView = (ListView) findViewById(R.id.list_view);
        mListView.setAdapter(mAdapter);
        findViewById(R.id.scan_delete_file).setOnClickListener(view -> scanDeleteFile());
        findViewById(R.id.scan_delete_file_delete).setOnClickListener(view -> deleteAllEmptyList());
        findViewById(R.id.scan_empty_file).setOnClickListener(view -> scanEmptyFile());
        mListView.setOnItemClickListener((adapterView, view, position, l) -> {
            ListBean item = mAdapter.getItem(position);
            if (!item.getFile().exists()) {
                toast("文件已被删除");
                return;
            }
            DialogUtils.show(MainActivity.this, "确认删除该文件吗?", (dialogInterface, i) -> {
                FileUtils.deleteFile(item.getFile());
                mAdapter.notifyDataSetChanged();
            });
        });
    }

    private void deleteAllEmptyList() {
        ArrayList<ListBean> allBeans = mAdapter.getAllBeans();
        if (allBeans.isEmpty()) {
            toast("没有扫描数据");
            return;
        }
        mAdapter.removeAllFile();
        mAdapter.notifyDataSetChanged();
        toast("删除成功");
    }

    private void scanDeleteFile() {
        mAdapter.removeAll();
        new Thread(() -> {
            ArrayList<ListBean> listBeans = FileUtils.getAllDeleteFile(this, rootFile);
            runOnUiThread(() -> {
                if (listBeans.isEmpty()) {
                    toast("没有扫描到垃圾文件");
                } else {
                    mAdapter.addAll(listBeans);
                }
            });
        }).start();
    }

    private void scanEmptyFile() {
        mAdapter.removeAll();
        new Thread(() -> {
            ArrayList<ListBean> listBeans = FileUtils.getAllEmptyFile(rootFile);
            runOnUiThread(() -> {
                if (listBeans.isEmpty()) {
                    toast("没有扫描到空文件夹");
                } else {
                    mAdapter.addAll(listBeans);
                }
            });
        }).start();
    }

    private void toast(String msg) {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }
}
