package com.file.clean.util;

import android.content.Context;
import android.content.res.AssetManager;

import com.file.clean.ListBean;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class FileUtils {

    //空文件夹
    private static final int TYPE_EMPTY_DIRECTORY = 0;
    //忽略文件夹
    private static final int TYPE_IGNORE_DIRECTORY = 1;
    //继续扫描
    private static final int TYPE_SCAN_DIRECTORY = 2;

    public static ArrayList<ListBean> getAllDeleteFile(Context context, File directory) {
        ArrayList<ListBean> listBeans = new ArrayList<>();
        try {
            String str = getJson(context);
            JSONArray jsonArray = new JSONArray(str);
            for (int i = 0; i < jsonArray.length(); i++) {
                String filePath = jsonArray.getJSONObject(i).getString("fileName");
                File file = new File(directory + filePath);
                if (file.exists()) {
                    listBeans.add(new ListBean(file));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return listBeans;
    }

    public static ArrayList<ListBean> getAllEmptyFile(File directory) {
        ArrayList<ListBean> listBeans = new ArrayList<>();
        for (File listFile : directory.listFiles()) {
            switch (isScan(listFile)) {
                case TYPE_EMPTY_DIRECTORY:
                    listBeans.add(new ListBean(listFile));
                    break;
                case TYPE_SCAN_DIRECTORY:
                    listBeans.addAll(getAllEmptyFile(listFile));
                    break;
                case TYPE_IGNORE_DIRECTORY:
                    // ignore
                    break;
            }
        }
        return listBeans;
    }

    private static int isScan(File file) {
        if (!file.isDirectory()) {
            return TYPE_IGNORE_DIRECTORY;
        }
        File[] listFiles = file.listFiles();
        if (listFiles.length == 0
                || listFiles.length == 1 && listFiles[0].getName().equals(".nomedia")
                || listFiles.length > 1 && !isNomediaFile(listFiles)) {
            return TYPE_EMPTY_DIRECTORY;
        }
        if (isNomedia(listFiles)) {
            return TYPE_IGNORE_DIRECTORY;
        }
        return TYPE_SCAN_DIRECTORY;
    }

    private static boolean isNomediaFile(File[] listFiles) {
        for (File listFile : listFiles) {
            if (!listFile.getName().startsWith(".")) {
                return true;
            }
        }
        return false;
    }

    private static boolean isNomedia(File[] listFiles) {
        for (File listFile : listFiles) {
            if (listFile.getName().equals(".nomedia")) {
                return true;
            }
        }
        return false;
    }

    private static String getJson(Context context) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            AssetManager assetManager = context.getAssets();
            BufferedReader bf = new BufferedReader(new InputStreamReader(assetManager.open("file.json")));
            String line;
            while ((line = bf.readLine()) != null) {
                stringBuilder.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuilder.toString();
    }

    public static boolean deleteFile(File dirFile) {
        if (!dirFile.exists()) {
            return false;
        }
        if (dirFile.isFile()) {
            return dirFile.delete();
        } else {
            for (File file : dirFile.listFiles()) {
                deleteFile(file);
            }
        }
        return dirFile.delete();
    }
}
