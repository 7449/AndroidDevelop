package com.file.clean.util;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;

public class DialogUtils {

    public static void show(Activity activity, String msg, DialogInterface.OnClickListener listener) {
        new AlertDialog.Builder(activity)
                .setTitle("提示")
                .setMessage(msg)
                .setPositiveButton("确定", listener)
                .show();
    }

}
