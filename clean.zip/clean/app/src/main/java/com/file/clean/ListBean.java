package com.file.clean;

import java.io.File;
import java.util.Objects;

public class ListBean {
    private File file;

    public ListBean(File file) {
        this.file = file;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ListBean)) return false;
        ListBean listBean = (ListBean) o;
        return Objects.equals(getFile(), listBean.getFile());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getFile());
    }
}
