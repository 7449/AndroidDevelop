package com.picture.main.detail

import android.common.core.DetailView
import android.common.ui.StatusActivity
import android.os.Bundle
import androidx.appcompat.widget.Toolbar
import androidx.viewpager.widget.ViewPager
import com.picture.main.R
import com.picture.main.net.PictureEntity
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.ui_activity_detail.*
import java.util.*

class DetailUiActivity : StatusActivity<DetailPresenter>(R.layout.ui_activity_detail), DetailView<List<PictureEntity>> {

    companion object {
        const val TYPE_URL = "detail_url"
    }

    private var url = ""
    private var toolbar: Toolbar? = null
    private var adapter: DetailUiAdapter = DetailUiAdapter(ArrayList())

    override fun initBundle(bundle: Bundle) {
        url = bundle.getString(TYPE_URL, "")
    }

    override fun initCreate(savedInstanceState: Bundle?) {
        toolbar = findViewById(R.id.toolbar)
        viewPager.adapter = adapter
        setTitles(1, adapter.count)
        mPresenter.onNetWork(url)
        viewPager.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                setTitles(position + 1, adapter.count)
            }
        })
        onStatusRetry()
    }

    override fun initPresenter(): DetailPresenter = DetailPresenterImpl(this)

    override fun onStatusRetry() {
        mPresenter.onNetWork(url)
    }

    override fun onNetSuccess(entity: List<PictureEntity>) {
        adapter.addAll(entity)
        setTitles(1, adapter.count)
    }

    private fun setTitles(page: Int, imageSize: Int) {
        toolbar?.title = "$page/$imageSize"
    }

    override fun hasStatusUI(): Boolean = true
}