package com.picture.main.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout
import com.picture.main.R

class TabFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_tab, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        view?.let {
            val tabLayout = it.findViewById<TabLayout>(R.id.tab_layout)
            val viewPager = it.findViewById<ViewPager>(R.id.viewPager)
            val tabAdapter = TabAdapter(childFragmentManager)
            viewPager.adapter = tabAdapter
            tabLayout.setupWithViewPager(viewPager)
            viewPager.offscreenPageLimit = tabAdapter.count
        }
    }
}