package com.picture.main.list

import android.common.ViewStatus
import android.common.loadNoMore
import android.common.ui.ListFragment
import android.os.Bundle
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.kotlin.x.currentActivity
import com.kotlin.x.glideFile
import com.kotlin.x.startActivity
import com.picture.main.R
import com.picture.main.detail.DetailUiActivity
import com.picture.main.net.PictureEntity
import com.xadapter.*
import kotlinx.android.synthetic.main.ui_fragment_list.*
import java.net.URL

class ListUiFragment : ListFragment<ListPresenter, List<PictureEntity>, PictureEntity>(R.layout.ui_fragment_list) {

    companion object {
        private const val INDEX = "INDEX"
        fun newInstance(position: Int): ListUiFragment {
            return ListUiFragment().apply { arguments = Bundle().apply { putInt(INDEX, position) } }
        }
    }

    private var tabPosition = 0

    override fun initPresenter(): ListPresenter = ListPresenterImpl(this)

    override fun swipeRefreshLayout(): SwipeRefreshLayout = swipeRefreshLayout

    override fun recyclerView(): RecyclerView = recyclerView

    override fun initBundle(bundle: Bundle) {
        tabPosition = bundle.getInt(INDEX, 0)
    }

    override fun initActivityCreated() {
        mAdapter
                .setItemLayoutId(R.layout.ui_item_list)
                .setLoadMoreListener { net(page, tabPosition, ViewStatus.LOAD_MORE) }
                .setRefreshListener {
                    page = 0
                    net(page, tabPosition, ViewStatus.REFRESH)
                }
                .setOnBind { holder, _, entity ->
                    holder.getImageView(R.id.image).glideFile(URL(entity.url))
                }
                .setOnItemClickListener { _, _, entity ->
                    currentActivity().startActivity(DetailUiActivity::class.java, Bundle().apply {
                        putString(DetailUiActivity.TYPE_URL, entity.detailUrl)
                    })
                }
        onStatusRetry()
    }

    override fun onStatusRetry() {
        page += 1
        net(page, tabPosition, ViewStatus.STATUS)
    }

    override fun onNetSuccess(entity: List<PictureEntity>) {
        if (mAdapter.dataContainer.containsAll(entity)) {
            mAdapter.loadNoMore()
            return
        }
        mAdapter.addAll(entity)
        onPagePlus()
    }

    private fun net(page: Int, tabPosition: Int, viewStatus: ViewStatus) {
        mPresenter.onNetWork(page, tabPosition, viewStatus)
    }
}
