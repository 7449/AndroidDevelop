package com.picture.main.net

import androidx.annotation.Keep

@Keep
data class PictureEntity(var url: String = "", var detailUrl: String = "")