package com.picture.main.list

import android.common.ViewStatus
import android.common.core.BasePresenter
import android.common.core.BasePresenterImpl
import android.common.core.RefreshView
import com.kotlin.x.LogE
import com.picture.main.net.Net
import com.picture.main.net.PictureEntity
import com.picture.main.net.pictureListApi
import io.reactivex.network.JsoupService
import io.reactivex.network.RxNetWork
import io.reactivex.network.cancelTag

interface ListPresenter : BasePresenter {
    fun onNetWork(page: Int, tabPosition: Int, viewStatus: ViewStatus)
}

class ListPresenterImpl(uiView: RefreshView<List<PictureEntity>>) : BasePresenterImpl<RefreshView<List<PictureEntity>>>(uiView), ListPresenter {

    override fun onNetWork(page: Int, tabPosition: Int, viewStatus: ViewStatus) {
        val url = String.format(Net.DB_URL, if (tabPosition == 0) 0 else tabPosition + 1, page)
        url.LogE()
        RxNetWork
                .observable(JsoupService::class.java)
                .get(url)
                .cancelTag(url.hashCode())
                .pictureListApi(url.hashCode(), mView, viewStatus) { it.isNullOrEmpty() }
    }
}