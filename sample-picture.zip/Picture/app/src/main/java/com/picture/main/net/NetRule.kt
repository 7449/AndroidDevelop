package com.picture.main.net

import org.jsoup.nodes.Document
import java.util.*

fun Document.getImageList(): List<PictureEntity> {
    val listModels = ArrayList<PictureEntity>()
    var imageListModel: PictureEntity
    val a = select("div.img_single").select("a")
    for (element in a) {
        imageListModel = PictureEntity()
        imageListModel.url = element.select("img[class]").attr("src")
        imageListModel.detailUrl = element.select("a[class]").attr("href")
        listModels.add(imageListModel)
    }
    return listModels
}

fun Document.getImageDetail(): List<PictureEntity> {
    val list = ArrayList<PictureEntity>()
    var imageDetailModel: PictureEntity
    val img = select("div.topic-richtext").select("img")
    for (element in img) {
        imageDetailModel = PictureEntity()
        imageDetailModel.url = element.select("img[src]").attr("src")
        list.add(imageDetailModel)
    }
    return list
}
