package com.picture.main.net

import android.common.ViewStatus
import android.common.core.DetailView
import android.common.core.RefreshView
import com.android.status.layout.StatusLayout
import io.reactivex.Observable
import io.reactivex.network.jsoupApi
import okhttp3.ResponseBody

/**
 * by y on 2016/7/26.
 */
object Net {
    const val BASE_URL = "https://www.buxiuse.com/"
    const val DB_URL = "https://www.buxiuse.com/?cid=%s&page=%s"
}

fun Observable<ResponseBody>.pictureDetailApi(tag: Any, view: DetailView<List<PictureEntity>>?) {
    jsoupApi<List<PictureEntity>>(tag) {
        onNetWorkStart { view?.onChangeLayoutStatus(StatusLayout.LOADING) }
        onNetWorkError { view?.onChangeLayoutStatus(StatusLayout.ERROR) }
        onNetWorkSuccess {
            view?.onChangeLayoutStatus(StatusLayout.SUCCESS)
            view?.onNetSuccess(it)
        }
        jsoupRule { it.getImageDetail() }
        getBaseUrl(Net.DB_URL)
    }
}

fun Observable<ResponseBody>.pictureListApi(tag: Any,
                                            view: RefreshView<List<PictureEntity>>?,
                                            type: ViewStatus,
                                            isNullOrEmpty: ((entity: List<PictureEntity>) -> Boolean)) {
    jsoupApi<List<PictureEntity>>(tag) {
        onNetWorkStart { if (type == ViewStatus.STATUS) view?.onChangeLayoutStatus(StatusLayout.LOADING) }
        onNetWorkError {
            if (view?.page ?: 1 == 1 && type == ViewStatus.STATUS) {
                view?.onChangeLayoutStatus(StatusLayout.ERROR)
            } else {
                view?.onNetError(type)
            }
        }
        onNetWorkSuccess {
            if (view?.page ?: 1 == 1) {
                view?.onRemoveAll()
            }
            if (isNullOrEmpty(it)) {
                if (view?.page ?: 1 == 1) {
                    view?.onChangeLayoutStatus(StatusLayout.EMPTY)
                } else {
                    view?.onLoadNoMore()
                }
            } else {
                if (view?.page ?: 1 == 1 && type == ViewStatus.STATUS) {
                    view?.onChangeLayoutStatus(StatusLayout.SUCCESS)
                } else {
                    view?.onNetComplete(type)
                }
                view?.onNetSuccess(it)
            }
        }
        jsoupRule { it.getImageList() }
        getBaseUrl(Net.DB_URL)
    }
}
