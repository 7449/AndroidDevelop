package com.picture.main.detail

import android.common.core.BasePresenter
import android.common.core.BasePresenterImpl
import android.common.core.DetailView
import com.kotlin.x.LogE
import com.picture.main.net.PictureEntity
import com.picture.main.net.pictureDetailApi
import io.reactivex.network.JsoupService
import io.reactivex.network.RxNetWork
import io.reactivex.network.cancelTag

interface DetailPresenter : BasePresenter {
    fun onNetWork(url: String)
}

class DetailPresenterImpl(uiView: DetailView<List<PictureEntity>>) : BasePresenterImpl<DetailView<List<PictureEntity>>>(uiView), DetailPresenter {

    override fun onNetWork(url: String) {
        url.LogE()
        RxNetWork
                .observable(JsoupService::class.java)
                .get(url)
                .cancelTag(url.hashCode())
                .pictureDetailApi(url.hashCode(), mView)
    }
}