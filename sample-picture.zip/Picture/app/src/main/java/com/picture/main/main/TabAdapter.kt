package com.picture.main.main

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.kotlin.x.getStringArray
import com.picture.main.App
import com.picture.main.R
import com.picture.main.list.ListUiFragment

class TabAdapter constructor(fm: FragmentManager) : FragmentPagerAdapter(fm) {
    private val name: Array<String> = App.instance.getStringArray(R.array.db_array)
    override fun getItem(position: Int): Fragment = ListUiFragment.newInstance(position)
    override fun getPageTitle(position: Int): CharSequence? = name[position]
    override fun getCount(): Int = name.size
}