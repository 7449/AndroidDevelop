package com.picture.main.detail

import android.common.widget.BasePagerAdapter
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.appcompat.widget.AppCompatImageView
import com.kotlin.x.glideFile
import com.picture.main.net.PictureEntity

class DetailUiAdapter constructor(data: MutableList<PictureEntity>) : BasePagerAdapter<PictureEntity>(data) {
    override fun instantiate(container: ViewGroup, position: Int, data: PictureEntity): Any {
        val imageView = AppCompatImageView(container.context)
        imageView.glideFile(data.url)
        container.addView(imageView, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT)
        return imageView
    }
}