package com.fuckapp.utils

/**
 * by y on 2016/10/31
 */

object Constant {
    const val ALL_APP = 1
    const val SYSTEM_APP = 2
    const val NO_SYSTEM_APP = 3
    const val HIDE_APP = 4
}
