package com.fuckapp.fragment.presenter

/**
 * by y on 2016/10/31
 */

interface AppPresenter {
    fun startApp(type: Int)
}
