package com.fuckapp.fragment.model

import android.graphics.drawable.Drawable

/**
 * by y on 2016/10/20.
 */

class AppModel {
    lateinit var appLabel: String
    lateinit var appIcon: Drawable
    lateinit var pkgName: String
}
