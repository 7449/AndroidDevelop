package com.wifi.core.devicescan;


import com.wifi.DeviceInfo;

public interface DeviceScanResult {
    void deviceScanResult(DeviceInfo deviceInfo);
}
