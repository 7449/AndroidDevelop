export const ExampleSchema = {
    name: 'Example',
    properties: {
        example: 'string',
    },
};
