package com.rn.netdetail.floattool;

public interface ObservableCall {

    PositionObservable getObservable();

    FloatingHelper getFloatingHelper();

}
