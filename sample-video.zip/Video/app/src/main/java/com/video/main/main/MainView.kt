package com.video.main.main

import android.common.core.BaseView
import androidx.appcompat.app.AppCompatActivity

interface MainView : BaseView {
    val mainActivity: AppCompatActivity
}
