package com.video.main

object BundleKey {

    const val searchKey = "searchKey"

    const val uiType = "uiType"

    const val suffix = "suffix"

    const val detailUri = "detailUri"

    const val detailTitle = "detailTitle"

    const val detailImage = "detailImage"

}