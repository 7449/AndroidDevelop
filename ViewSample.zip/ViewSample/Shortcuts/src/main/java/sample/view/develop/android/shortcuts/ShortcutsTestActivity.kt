package sample.view.develop.android.shortcuts

import android.os.Bundle
import android.support.v7.app.AppCompatActivity

/**
 * by y on 2017/4/21
 */

class ShortcutsTestActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.shortcuts_activity_test)
    }
}
