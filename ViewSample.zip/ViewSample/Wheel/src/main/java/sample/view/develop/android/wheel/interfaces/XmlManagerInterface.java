package sample.view.develop.android.wheel.interfaces;

/**
 * by y on 2016/10/26
 */
public interface XmlManagerInterface {
    void updateAreas(String[] areas);

    void updateCities(String[] cities);
}
