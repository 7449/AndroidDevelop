package sample.view.develop.android.wheel.interfaces;

/**
 * by y on 2016/10/26
 */

public interface XmlPopupWindowInterface {
    void setData(String currentProviceName, String currentCityName, String currentDistrictName);
}
