package sample.view.develop.android.numberpicker.widget.handler;

import android.os.Handler;
import android.os.Message;

/**
 * by y on 2017/3/16
 */

public class PickerInNewHandler extends Handler {
    @Override
    public void handleMessage(Message msg) {
        super.handleMessage(msg);
    }

    public interface PickerInNewListener {
    }
}
