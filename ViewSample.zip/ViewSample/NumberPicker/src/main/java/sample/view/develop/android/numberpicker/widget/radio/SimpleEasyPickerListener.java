package sample.view.develop.android.numberpicker.widget.radio;

/**
 * by y on 2017/3/16
 * <p>
 * 简单的EasyPickListener
 */

public class SimpleEasyPickerListener implements EasyPickerListener {

    @Override
    public void onEasyCancel() {

    }

    @Override
    public void onEasyNext(String value) {

    }
}
