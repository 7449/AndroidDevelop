package com.xyz.ds

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import android.widget.TextView
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.io.UnsupportedEncodingException

const val BASE_URL = "https://www.ds45.xyz/"

const val PAGE_URL = "/index.php?page=%s"

data class ListEntity(
    val title: String = "",
    val time: String = "",
    val detailUri: String = ""
)

data class DetailEntity(
    val magnet: String = "",
    val torrent: String = "",
    val info: List<String> = emptyList(),
    val bigImages: List<String> = emptyList(),
    val images: List<String> = emptyList()
)

fun Context.sharedPreferences(): SharedPreferences =
    applicationContext.getSharedPreferences("GodBt", Context.MODE_PRIVATE)

fun Context.baseUri(): String = sharedPreferences().getString("baseUri", BASE_URL) ?: BASE_URL

fun Context.baseUri(value: String) =
    sharedPreferences().edit().putString("baseUri", value).apply()

/** base64解密 */
val String.decodeToString: String
    get() {
        try {
            return String(Base64.decode(toByteArray(), Base64.DEFAULT))
        } catch (e: UnsupportedEncodingException) {
            e.printStackTrace()
        }
        return ""
    }

fun String.getDetailEntity(baseUri: String): DetailEntity {
    val body = Jsoup.parse(this.replace("<!--", "").replace("-->", ""), baseUri).body()
    val elements = body.select("div#content")
    val infoList = ArrayList<String>()
    val imagesList = ArrayList<String>()
    val bigImagesList = ArrayList<String>()
    val selectInfo = elements.select("p")
    infoList.add(0, selectInfo.safeValue(0, ""))
    infoList.add(1, selectInfo.safeValue(1, ""))
    infoList.add(2, selectInfo.safeValue(2, ""))
    infoList.add(3, selectInfo.safeValue(3, ""))
    infoList.add(4, selectInfo.safeValue(4, ""))
    val imageInfo = elements.select("a[href]:has(img)")
    for (element in imageInfo) {
        val attr = element.select("img[src]").attr("abs:src")
        val bigImage = element.select("a[href]").attr("abs:href")
        if (attr.isNotEmpty() && bigImage.isNotEmpty()) {
            imagesList.add(attr)
            bigImagesList.add(bigImage)
        }
    }
    val torrent = elements.select("a[href]:has(font)").attr("abs:href")
    val magnet = elements.select("a[href]").safeValue(0, "")
    return DetailEntity(
        magnet = magnet,
        torrent = torrent,
        info = infoList,
        images = imagesList,
        bigImages = bigImagesList
    )
}

fun String.getListEntity(baseUri: String): ArrayList<ListEntity> {
    val body = Jsoup.parse(this, baseUri)
    val elements = body.select("li:has(script)")
    val arrayList = ArrayList<ListEntity>()
    elements.forEach {
        val script = it.select("script").toString()
        val title = script.substring(script.indexOf("('") + 2, script.indexOf("')"))
        arrayList.add(
            ListEntity(
                time = it.text(),
                title = title,
                detailUri = it.select("a[href]").attr("abs:href")
            )
        )
    }
    return arrayList
}

fun String.onCheckHtml(): String? {
    val document = Jsoup.parse(this)
    if (document.body().text().isEmpty()) {
        val html = document.select("script").html()
        return html.removePrefix("window.location.href='").removeSuffix("'")
    }
    return null
}

fun List<Element>.safeValue(index: Int, defaultValue: String): String {
    return if (index < size) {
        get(index).text()
    } else {
        defaultValue
    }
}

fun TextView.padding() {
    setPadding(10, 5, 10, 5)
}
