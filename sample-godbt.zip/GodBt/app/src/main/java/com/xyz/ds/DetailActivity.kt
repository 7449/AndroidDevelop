package com.xyz.ds

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.status.layout.OnEmptyClick
import com.android.status.layout.OnErrorClick
import com.android.status.layout.StatusLayout
import com.android.status.layout.setStatus
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.davemorrissey.labs.subscaleview.ImageSource
import com.xadapter.recyclerview.*
import com.xadapter.vh.imageView
import io.reactivex.jsoup.JsoupService
import io.reactivex.network.RxNetWork
import io.reactivex.network.cancel
import io.reactivex.network.request
import kotlinx.android.synthetic.main.activity_detail.*
import kotlinx.android.synthetic.main.layout_detail_success.*


class DetailActivity : AppCompatActivity() {

    companion object {
        private const val URL = "URL"
        private const val TITLE = "TITLE"
        private const val BASEURI = "BASEURI"
        fun start(url: String, title: String, baseUri: String, activity: AppCompatActivity) {
            activity.startActivity(Intent(activity, DetailActivity::class.java).apply {
                putExtra(URL, url)
                putExtra(TITLE, title)
                putExtra(BASEURI, baseUri)
            })
        }
    }

    private val url: String by lazy { intent.getStringExtra(URL) }
    private val title: String by lazy { intent.getStringExtra(TITLE) }
    private val baseUri: String by lazy { intent.getStringExtra(BASEURI) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        setTitle(title)
        statusLayout.OnEmptyClick { request() }.OnErrorClick { request() }
        request()
    }

    private fun request() {
        JsoupService
            .createGET(url)
            .cancel(javaClass.simpleName)
            .request(javaClass.simpleName) {
                onNetWorkStart { statusLayout.setStatus(StatusLayout.LOADING) }
                onNetWorkError { statusLayout.setStatus(StatusLayout.ERROR) }
                onNetWorkSuccess { it ->
                    it.charStream().let {
                        statusLayout.setStatus(StatusLayout.SUCCESS)
                        onRequestSuccess(it.readText())
                        it.close()
                    }
                }
            }
    }

    @SuppressLint("SetTextI18n")
    private fun onRequestSuccess(readText: String) {
        val detailItem = readText.getDetailEntity(baseUri)
        if (detailItem.magnet.isNotEmpty()) {
            detailInfo.addView(TextView(this).apply {
                text = "磁力链接(点击复制)\n${detailItem.magnet}"
                padding()
                setOnClickListener { copy(detailItem.magnet) }
            })
        }
        if (detailItem.torrent.isNotEmpty()) {
            detailInfo.addView(TextView(this).apply {
                text = "种子下载地址(点击复制)\n${detailItem.torrent}"
                padding()
                setOnClickListener { copy(detailItem.torrent) }
            })
        }
        for (info in detailItem.info) {
            detailInfo.addView(TextView(this).apply {
                text = info
                padding()
            })
        }
        recyclerView
            .fixedSize()
            .gridLayoutManager(3)
            .attachAdapter<String>()
            .setItemLayoutId(R.layout.item_detail)
            .setOnBind<String> { holder, _, entity ->
                Glide.with(this).load(entity).into(holder.imageView(R.id.detailImage))
            }
            .setOnItemClickListener<String> { _, _, entity ->
                imageView.visibility = View.VISIBLE
                Glide.with(this@DetailActivity)
                    .asBitmap()
                    .load(entity)
                    .into(object : SimpleTarget<Bitmap>() {
                        override fun onResourceReady(
                            resource: Bitmap,
                            transition: Transition<in Bitmap>?
                        ) {
                            imageView.setImage(ImageSource.cachedBitmap(resource))
                        }
                    })
            }
            .addAll(detailItem.images)
    }

    override fun onBackPressed() {
        if (imageView.visibility == View.VISIBLE) {
            imageView.visibility = View.GONE
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        RxNetWork.instance.cancel(javaClass.simpleName)
        super.onDestroy()
    }

    private fun copy(text: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(null, text))
        Toast.makeText(this, "复制成功", Toast.LENGTH_SHORT).show()
    }

}