package com.xyz.ds

import android.app.Application
import io.reactivex.network.DefaultRxNetOption
import io.reactivex.network.RxNetWork
import retrofit2.converter.gson.GsonConverterFactory

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        RxNetWork.initialization(
            DefaultRxNetOption(
                baseUrl = BASE_URL,
                converterFactory = GsonConverterFactory.create()
            )
        )
    }
}