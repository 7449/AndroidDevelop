package com.xyz.ds

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.status.layout.OnEmptyClick
import com.android.status.layout.OnErrorClick
import com.android.status.layout.StatusLayout
import com.android.status.layout.setStatus
import com.xadapter.recyclerview.*
import com.xadapter.refresh.XLoadMoreView
import com.xadapter.refresh.XRefreshView
import com.xadapter.vh.setText
import io.reactivex.jsoup.JsoupService
import io.reactivex.network.RxNetWork
import io.reactivex.network.cancel
import io.reactivex.network.request
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.layout_list_success.*

class MainActivity : AppCompatActivity() {

    private var page: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        statusLayout.OnEmptyClick { requestFirst(false) }.OnErrorClick { requestFirst(false) }
        recyclerView
            .fixedSize()
            .linearLayoutManager()
            .attachAdapter<ListEntity>()
            .setItemLayoutId(R.layout.item_list)
            .openLoadingMore()
            .openPullRefresh()
            .setOnBind<ListEntity> { holder, _, entity ->
                holder.setText(R.id.tv_title, entity.title.decodeToString)
                holder.setText(R.id.tv_time, entity.time)
            }
            .setOnItemClickListener<ListEntity> { _, _, entity ->
                DetailActivity.start(
                    entity.detailUri, entity.title.decodeToString, baseUri(), this
                )
            }
            .setRefreshListener { requestFirst(true) }
            .setLoadMoreListener { request(true, page) }
        requestFirst(false)
    }

    private fun requestFirst(isTouch: Boolean) {
        page = 1
        request(isTouch, page)
    }

    private fun request(isTouch: Boolean, page: Int) {
        val uri = if (page == 1) baseUri() else baseUri() + PAGE_URL.format(page)
        Log.i(javaClass.simpleName, uri)
        JsoupService
            .createGET(uri)
            .cancel(javaClass.simpleName)
            .request(javaClass.simpleName) {
                onNetWorkStart { onRequestStart(isTouch) }
                onNetWorkError { onRequestError(isTouch) }
                onNetWorkSuccess { it ->
                    it.charStream().let {
                        val readText = it.readText()
                        val onCheckHtml = readText.onCheckHtml()
                        if (onCheckHtml.isNullOrEmpty()) {
                            onRequestSuccess(isTouch, readText)
                        } else {
                            Toast.makeText(
                                applicationContext,
                                "检测到url地址已发生变化,获取到新的url:${onCheckHtml},重新请求数据...",
                                Toast.LENGTH_LONG
                            ).show()
                            baseUri(onCheckHtml)
                            request(isTouch, page)
                        }
                        it.close()
                    }
                }
            }
    }

    private fun onRequestSuccess(isTouch: Boolean, value: String) {
        val arrayList = value.getListEntity(baseUri())
        if (arrayList.isEmpty() && page == 1) {
            statusLayout.setStatus(StatusLayout.EMPTY)
            return
        }
        if (arrayList.isEmpty() && page != 1) {
            recyclerView.setLoadMoreState(XLoadMoreView.NO_MORE)
            return
        }
        if (!isTouch && page == 1) {
            statusLayout.setStatus(StatusLayout.SUCCESS)
        } else if (page == 1) {
            recyclerView.setRefreshState(XRefreshView.SUCCESS)
        } else {
            recyclerView.setLoadMoreState(XLoadMoreView.SUCCESS)
        }
        if (page == 1) {
            recyclerView.removeAll()
        }
        page += 1
        if (arrayList.isNotEmpty()) {
            recyclerView.addAll(arrayList)
        }
    }

    private fun onRequestStart(isTouch: Boolean) {
        if (!isTouch && page == 1) {
            statusLayout.setStatus(StatusLayout.LOADING)
        } else if (page == 1) {
            // do nothing
        } else {
            recyclerView.setLoadMoreState(XLoadMoreView.LOAD)
        }
    }

    private fun onRequestError(isTouch: Boolean) {
        if (!isTouch && page == 1) {
            statusLayout.setStatus(StatusLayout.ERROR)
        } else if (page == 1) {
            recyclerView.setRefreshState(XRefreshView.ERROR)
        } else {
            recyclerView.setLoadMoreState(XLoadMoreView.ERROR)
        }
    }

    override fun onDestroy() {
        RxNetWork.instance.cancel(javaClass.simpleName)
        super.onDestroy()
    }
}