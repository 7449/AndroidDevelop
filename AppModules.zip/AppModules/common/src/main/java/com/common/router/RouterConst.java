package com.common.router;

public interface RouterConst {
    String ACT_MAIN_KEY = "://activity/main";
}
