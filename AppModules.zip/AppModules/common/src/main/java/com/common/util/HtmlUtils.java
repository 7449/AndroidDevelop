package com.common.util;

public class HtmlUtils {

    public static String getCoding() {
        return "utf-8";
    }

    public static String getMimeType() {
        return "text/html";
    }
}
