package com.common.widget.toolbar;

public interface OnToolBarClickListener {
    void onLeftClick();

    void onCenterClick();

    void onRightClick();
}
