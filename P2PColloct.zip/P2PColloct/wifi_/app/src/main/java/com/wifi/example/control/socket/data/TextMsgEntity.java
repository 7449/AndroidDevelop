package com.wifi.example.control.socket.data;

public class TextMsgEntity extends MsgEntity {

    /**
     * 文本内容
     */
    public String msgContent;

}
