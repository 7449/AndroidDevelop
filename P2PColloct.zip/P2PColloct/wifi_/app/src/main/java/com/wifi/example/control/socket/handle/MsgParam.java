package com.wifi.example.control.socket.handle;


import com.wifi.example.control.socket.data.MsgEntity;

public class MsgParam {

    private MsgEntity mMsgEntity;

    public MsgEntity getMsgEntity() {
        return mMsgEntity;
    }

    public void setMsgEntity(MsgEntity entity) {
        this.mMsgEntity = entity;
    }

}
