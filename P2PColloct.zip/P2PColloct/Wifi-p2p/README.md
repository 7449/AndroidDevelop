# FileP2P

Wifi Direct，实现Android手机之间无网络传输文件

### 具体介绍可以看我的博客：[Android 实现无网络传输文件](https://www.jianshu.com/p/f5d66e15fbdf)


### 此外，可以看下另一个通过Wifi热点配对设备后传输文件的方法：[Android 实现无网络传输文件（2）](https://github.com/leavesC/WifiFileTransfer)
