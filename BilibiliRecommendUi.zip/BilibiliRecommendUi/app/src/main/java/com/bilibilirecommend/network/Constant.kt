package com.bilibilirecommend.network

object Constant {
    const val TYPE_RECOMMEND = "recommend" //热门焦点
    const val TYPE_LIVE = "live" //热门直播
    const val TYPE_BANGUMI = "bangumi_2" //番剧推荐
    const val TYPE_REGION = "region" //动画区 音乐区  舞蹈区 游戏区 鬼畜区 科技区 生活区 时尚区 娱乐区 电视剧区 电影区
    const val TYPE_WEB_LINK = "weblink" //话题 话题 话题
    const val TYPE_ACTIVITY_ = "activity" //活动中心
}
