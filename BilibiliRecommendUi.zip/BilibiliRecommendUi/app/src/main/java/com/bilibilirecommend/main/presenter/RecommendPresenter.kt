package com.bilibilirecommend.main.presenter

interface RecommendPresenter {
    fun netWorkRequest(plat: Int)
}
