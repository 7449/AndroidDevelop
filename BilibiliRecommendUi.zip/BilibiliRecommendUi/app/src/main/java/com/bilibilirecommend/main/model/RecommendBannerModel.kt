package com.bilibilirecommend.main.model

import com.bannerlayout.model.BannerModel

class RecommendBannerModel {
    var code: Int = 0
    lateinit var data: List<BannerModel>
}
