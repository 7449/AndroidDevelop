package objectbox.develop.android.two

import io.objectbox.BoxStore
import objectbox.develop.android.entity.DaoSession

object ObjectBox2xUtils {
    lateinit var boxStore: BoxStore
    lateinit var dao: DaoSession
}
