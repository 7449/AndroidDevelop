package objectbox.develop.android.multitable

import io.objectbox.BoxStore

object MultiTableObjectBoxUtils {
    lateinit var boxStore: BoxStore
}
