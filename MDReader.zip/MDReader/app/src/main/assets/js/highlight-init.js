function highlight_init() {
    if(hljs) hljs.initHighlightingOnLoad();
}

highlight_init();