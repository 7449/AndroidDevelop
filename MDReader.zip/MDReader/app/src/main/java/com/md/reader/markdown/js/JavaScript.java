package com.md.reader.markdown.js;

public interface JavaScript {
    String toHTML();
}
