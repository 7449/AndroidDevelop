package com.md.reader.markdown.css;

public interface StyleSheet {
    String toHTML();
}
