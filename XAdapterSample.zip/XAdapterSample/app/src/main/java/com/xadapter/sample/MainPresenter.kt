package com.xadapter.sample

/**
 * by y.
 *
 *
 * Description:
 */
interface MainPresenter {
    fun onNetRequest(page: Int, type: Int)
}
