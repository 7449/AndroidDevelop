package com.xadapter.sample

/**
 * by y.
 *
 *
 * Description:
 */
class Entity(var title: String, var titleImage: String)
