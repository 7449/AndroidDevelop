package sample.util.develop.android.linktop

import android.os.Bundle
import android.support.v7.app.AppCompatActivity


class LinkTopMainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.link_top_activity_main)
    }
}
