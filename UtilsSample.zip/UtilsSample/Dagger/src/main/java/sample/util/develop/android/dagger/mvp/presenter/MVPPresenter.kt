package sample.util.develop.android.dagger.mvp.presenter

/**
 * by y on 2017/5/31.
 */

interface MVPPresenter {
    fun startNetWork()
}
