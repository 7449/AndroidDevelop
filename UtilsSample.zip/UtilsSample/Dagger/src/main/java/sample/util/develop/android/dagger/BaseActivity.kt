package sample.util.develop.android.dagger

import android.support.v7.app.AppCompatActivity

/**
 * by y on 2017/5/31.
 */

abstract class BaseActivity : AppCompatActivity()
