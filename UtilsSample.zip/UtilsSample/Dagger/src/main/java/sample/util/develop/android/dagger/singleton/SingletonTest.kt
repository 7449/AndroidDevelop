package sample.util.develop.android.dagger.singleton

import javax.inject.Inject
import javax.inject.Singleton

/**
 * by y on 2017/5/31.
 */
@Singleton
class SingletonTest @Inject
constructor()
