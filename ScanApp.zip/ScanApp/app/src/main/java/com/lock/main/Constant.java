package com.lock.main;

/**
 * by y on 2017/2/15
 */

public class Constant {

    public static final String APP_PACKAGE_NAME = "com.lock";
    public static final String FRAGMENT_TAG = "tag";
    public static final String START_SETTING_SCHEME = "package";
}
