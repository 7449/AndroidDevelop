package com.lock.showapp.presenter;

/**
 * by y on 2017/2/16
 */

public interface ShowPresenter {
    void showLayout(boolean b);
}
