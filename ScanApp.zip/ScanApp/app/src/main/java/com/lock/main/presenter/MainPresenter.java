package com.lock.main.presenter;

/**
 * by y on 2017/2/16
 */

public interface MainPresenter {
    void registerUser(String userName, String passWord);
}
