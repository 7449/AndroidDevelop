package com.lock.setting.view;

/**
 * by y on 2017/2/16
 */

public interface SettingView {
    void exitApp();

    void alterPassWord();

    void deleteApp();

    void clearSetting();
}
