package com.lock.checkapp.presenter;

/**
 * by y on 2017/2/16
 */

public interface CheckPresenter {
    void onScanApp();

    void onClick(int id);
}
