package com.lock.showapp.view;

/**
 * by y on 2017/2/16
 */

public interface ShowView {
    void initRecyclerView();

    void showEmptyView();

    void hideRecyclerView();

    void hideEmptyView();

    void showRecyclerView();
}
