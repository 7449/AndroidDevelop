package com.android.mvp.lifecycle.mvp

import com.android.mvp.lifecycle.base.BaseIView

/**
 * @author y
 * @create 2019/3/31
 */
interface MainView : BaseIView {

    fun showToast()

}
