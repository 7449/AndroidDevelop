package com.tencent.qbar;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 调用顺序
 * {@link #releaseAssert(Context)}
 * {@link #init(Context)}
 * {@link #setReader()}
 * <p>
 * 结束的时候调用{@link #release()}
 */
public class QrCode {

    private static final String TAG = "QrCode";

    static {
        System.loadLibrary("wechatQrMod");
    }

    private void qbarIdNull() {
        Log.e(TAG, "Qbar id == null");
    }

    private void qbarIdNotNull() {
        Log.e(TAG, "Qbar id != null");
    }

    private Integer id;

    public static QrCode create(Context context) throws IOException {
        QrCode qrCode = new QrCode();
        qrCode.releaseAssert(context);
        qrCode.init(context);
        qrCode.setReader();
        return qrCode;
    }

    public void open(Context context) throws IOException {
        releaseAssert(context);
        init(context);
        setReader();
    }

    public boolean isInit() {
        return id != null;
    }

    public void releaseAssert(Context context) throws IOException {
        releaseAssert(context, "qbar");
    }

    /**
     * 释放扫码必备的资源文件
     * <p>
     * 主要释放Assert下对qbar文件到 /data/data/package/files/qbar 下
     *
     * @param context 上下文
     * @param folder  输出到文件夹名称 默认：qbar
     * @throws IOException 可能文件权限有问题
     */
    public void releaseAssert(Context context, String folder) throws IOException {
        File outputFolder = new File(context.getFilesDir(), folder);
        if (!outputFolder.exists()) {
            outputFolder.mkdirs();
        }
        AssetManager assets = context.getAssets();
        IOUtils.copy(assets.open("qbar/detect_model.bin"), new File(outputFolder, "detect_model.bin"));
        IOUtils.copy(assets.open("qbar/detect_model.param"), new File(outputFolder, "detect_model.param"));
        IOUtils.copy(assets.open("qbar/srnet.bin"), new File(outputFolder, "srnet.bin"));
        IOUtils.copy(assets.open("qbar/srnet.param"), new File(outputFolder, "srnet.param"));
    }

    public boolean init(Context context) throws IOException {
        return init(context, "qbar");
    }

    /**
     * 初始化扫一扫模块
     * <p>
     * 在初始化一定要释放扫码资：releaseAssert
     *
     * @param folder 释放文件的文件夹
     * @return true => 成功
     * @throws IOException 找不到初始化的各项资源
     */
    public boolean init(Context context, String folder) throws IOException {
        return init(new File(context.getFilesDir(), folder).getAbsoluteFile());
    }

    /**
     * 初始化扫一扫模块
     * 此方法减少了context参数
     *
     * @param folder 释放的资源完整路径
     * @return true => 成功
     * @throws IOException 找不到初始化的各项资源
     */
    public boolean init(File folder) throws IOException {
        if (id != null) {
            qbarIdNotNull();
            return false;
        }
        File detectModelBinPathFile = new File(folder, "detect_model.bin");
        File detectModelParamPath = new File(folder, "detect_model.param");
        File superResolutionModelBinPath = new File(folder, "srnet.bin");
        File superResolutionModelParamPath = new File(folder, "srnet.param");
        if (!detectModelBinPathFile.exists()) {
            throw new IOException();
        }
        if (!detectModelParamPath.exists()) {
            throw new IOException();
        }
        if (!superResolutionModelBinPath.exists()) {
            throw new IOException();
        }
        if (!superResolutionModelParamPath.exists()) {
            throw new IOException();
        }
        QbarNative.QbarAiModelParam qbarAiModelParam = new QbarNative.QbarAiModelParam();
        qbarAiModelParam.detect_model_bin_path_ = detectModelBinPathFile.getAbsolutePath();
        qbarAiModelParam.detect_model_param_path_ = detectModelParamPath.getAbsolutePath();
        qbarAiModelParam.superresolution_model_bin_path_ = superResolutionModelBinPath.getAbsolutePath();
        qbarAiModelParam.superresolution_model_param_path_ = superResolutionModelParamPath.getAbsolutePath();
        id = QbarNative.Init(1, 0, "ANY", "UTF-8", qbarAiModelParam);
        return id == 0;
    }

    public boolean setReader() {
        return setReader(new int[]{2, 1});
    }

    /**
     * 设置解码器
     *
     * @param intArray 解码支持参数
     *                 具体数值暂时不清楚
     *                 请固定填写: 2, 1
     * @return true => 成功
     */
    public boolean setReader(int[] intArray) {
        if (id == null) {
            qbarIdNull();
            return false;
        } else {
            int i = QbarNative.SetReaders(intArray, intArray.length, id);
            return i == 0;
        }
    }

    /**
     * 当前扫一扫版本信息
     *
     * @return 3.2.20190712
     */
    public String getVersion() {
        return QbarNative.GetVersion();
    }

    /**
     * 关闭
     *
     * @return true 释放成功
     */
    public boolean release() {
        if (id == null) {
            qbarIdNull();
            return false;
        } else {
            QbarNative.Release(id);
            id = null;
            return true;
        }
    }

    /**
     * 相机预览的数据
     *
     * @param data     相机数据
     * @param size     data对应的图片大小
     * @param crop     裁剪的图片大小
     * @param rotation 旋转图片角度
     * @return 扫描完成的List
     */
    public List<QbarNative.QBarResultJNI> onPreviewFrame(byte[] data, Point size, Rect crop, int rotation) {
        if (id == null) {
            throw new IllegalArgumentException("did init ?");
        }
        int[] nativeGrayRotateCropSubDataWH = new int[2];
        byte[] nativeGrayRotateCropSubData = new byte[crop.width() * crop.height() * 3 / 2];
        int nativeGrayRotateCropSubResult = QbarNative.nativeGrayRotateCropSub(
                data,
                size.x,
                size.y,
                crop.left,
                crop.top,
                crop.width(),
                crop.height(),
                nativeGrayRotateCropSubData,
                nativeGrayRotateCropSubDataWH,
                rotation,
                0
        );
        if (nativeGrayRotateCropSubResult != 0) {
            throw new RuntimeException("Native.nativeGrayRotateCropSub error: " + nativeGrayRotateCropSubResult);
        }
        int scanImageResult = QbarNative.ScanImage(
                Arrays.copyOf(nativeGrayRotateCropSubData, nativeGrayRotateCropSubData.length),
                nativeGrayRotateCropSubDataWH[0],
                nativeGrayRotateCropSubDataWH[1],
                id);
        if (scanImageResult != 0) {
            throw new RuntimeException("Native.ScanImage error: " + scanImageResult);
        }

        QbarNative.QBarResultJNI[] qBarResultJNIArr = new QbarNative.QBarResultJNI[]{
                new QbarNative.QBarResultJNI(), new QbarNative.QBarResultJNI(), new QbarNative.QBarResultJNI()
        };

        QbarNative.QBarPoint[] qBarPointArr = new QbarNative.QBarPoint[]{
                new QbarNative.QBarPoint(), new QbarNative.QBarPoint(), new QbarNative.QBarPoint()
        };

        WxQbarNative.QBarReportMsg[] qBarReportMsgArr = new WxQbarNative.QBarReportMsg[]{
                new WxQbarNative.QBarReportMsg(), new WxQbarNative.QBarReportMsg(), new WxQbarNative.QBarReportMsg()
        };

        int getDetailResults = WxQbarNative.GetDetailResults(qBarResultJNIArr, qBarPointArr, qBarReportMsgArr, id);
        if (getDetailResults < 0) {
            throw new RuntimeException("Native.GetDetailResults error: " + getDetailResults);
        }
        ArrayList<QbarNative.QBarResultJNI> qBarResultJNIS = new ArrayList<>();
        for (QbarNative.QBarResultJNI qBarResultJNI : qBarResultJNIArr) {
            if (qBarResultJNI.typeName != null && qBarResultJNI.typeName.length() > 0) {
                qBarResultJNIS.add(qBarResultJNI);
            }
        }
        return qBarResultJNIS;
    }


}
