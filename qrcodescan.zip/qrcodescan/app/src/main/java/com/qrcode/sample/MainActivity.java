package com.qrcode.sample;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.graphics.Rect;
import android.hardware.Camera;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.SurfaceView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.tencent.qbar.QbarNative;
import com.tencent.qbar.QrCode;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;

public class MainActivity extends Activity implements Camera.PreviewCallback, Camera.AutoFocusCallback {

    private static final String TAG = "MainActivity";
    private static final int REQUEST_CAMERA_PERMISSION = 1;

    private QrCode wechatScanner = new QrCode();
    private SurfaceView surfaceView;
    private TextView textView;
    private Camera camera;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        surfaceView = findViewById(R.id.surfaceView);
        textView = findViewById(R.id.textView);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (permissions.length != 1 || grantResults.length != 1) {
                throw new RuntimeException("Error on requesting camera permission.");
            }
            if (grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "权限...", Toast.LENGTH_SHORT).show();
            }
            startCamera();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        releaseCamera();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        releaseCamera();
        if (wechatScanner != null) {
            wechatScanner.release();
        }
    }

    private void initScan() {
        if (wechatScanner.isInit()) {
            return;
        }
        try {
            wechatScanner.open(getApplicationContext());
            textView.setText(wechatScanner.getVersion());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void startCamera() {
        new Handler().postDelayed(() -> {
            try {
                Log.e(TAG, "init camera");
                initScan();
                camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_BACK);
                camera.setPreviewDisplay(surfaceView.getHolder());
                camera.setDisplayOrientation(90);
                Camera.Parameters parameters = camera.getParameters();
                parameters.setFocusMode(Camera.Parameters.ANTIBANDING_AUTO);
                camera.setParameters(parameters);
                camera.setPreviewCallback(MainActivity.this);
                camera.startPreview();
                camera.autoFocus(MainActivity.this);
            } catch (IOException e) {
                Log.e(TAG, e.getMessage());
                e.printStackTrace();
            }
        }, 200);
    }

    private void releaseCamera() {
        if (camera != null) {
            camera.stopPreview();
            camera.setPreviewCallback(null);
            camera.release();
            camera = null;
        }
    }

    @Override
    public void onPreviewFrame(byte[] bytes, Camera camera) {
        if (!wechatScanner.isInit()) {
            return;
        }
        long startTimestamp = System.currentTimeMillis();

        List<QbarNative.QBarResultJNI> scanResultList = wechatScanner.onPreviewFrame(
                bytes,
                new Point(camera.getParameters().getPreviewSize().width, camera.getParameters().getPreviewSize().height),
                new Rect(40, (surfaceView.getWidth() / 2) - 200, surfaceView.getWidth() - 40, surfaceView.getWidth() + 200),
                90);
        if (scanResultList.isEmpty()) {
            return;
        }
        for (QbarNative.QBarResultJNI qBarResultJNI : scanResultList) {
            Log.i(TAG, "onPreviewFrame typeName=" + qBarResultJNI.typeName + " charset=" + qBarResultJNI.charset + " data=" + new String(qBarResultJNI.data, Charset.forName(qBarResultJNI.charset)));
        }
        textView.post(() -> {
            QbarNative.QBarResultJNI qBarResultJNI = scanResultList.get(0);
            textView.setText(new String(qBarResultJNI.data, Charset.forName(qBarResultJNI.charset)));
        });
        Log.i(TAG, "onPreviewFrame scan cost: " + (System.currentTimeMillis() - startTimestamp) + "ms");
    }

    @Override
    public void onAutoFocus(boolean success, Camera camera) {
        Log.i(TAG, "onAutoFocus success=" + success);
    }
}

