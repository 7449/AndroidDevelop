module.exports = {

    NetWorkType: {
        LOGIN:0
    }
};